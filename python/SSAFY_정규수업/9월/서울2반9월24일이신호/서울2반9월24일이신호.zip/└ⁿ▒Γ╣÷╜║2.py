def grid_min(location, result):
    global min_count, N, count
    count += 1

    if location >= N-1:
        if min_count> result:
            min_count = result
        return
    power = bus_stops[location]
    max_index = 0
    max_vlaue = 0
    for i in range(1, power+1):
        if location + i > N-2:
            continue
        if bus_stops[location+i] >= max_vlaue:
            max_vlaue = bus_stops[location+i]
            max_index = location + i

    if max_index >= N-2:
        min_count = result + 1
        return
    grid_min(max_index, result+1)

def move(location, result):
    global min_count, N, count
    count += 1
    if location >= N - 1:
        if min_count > result:
            min_count = result
        return
    if result > min_count:
        return
    power = bus_stops[location]
    for i in range(power, -1, -1):
        if i == 0:
            break
        if location + i > N -1:
            continue

        move(location + i, result + 1)


T = int(input())

for tc in range(1, T+1):
    arr = list(map(int, input().split()))
    N = arr[0]
    count = 0
    bus_stops = arr[1:]
    min_count = 1000000000000000000000
    grid_min(0,-1)
    move(0, -1)
    print('#%s %s' % (tc,min_count))
